
public class Customerclass extends Thread{
	
private Shopping s;
	public Customerclass(Shopping shopping) {
		this.s=shopping;
	}
	@Override
		public void run() {
			// TODO Auto-generated method stub
			super.run();
			s.displaydata();
		}
}
