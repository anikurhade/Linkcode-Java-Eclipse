
public class Shopping {
public void Storedata()
{
	for (int i = 0; i < 5; i++) {
		System.out.println("Storing Data");
	}
}
public void displaydata() {
	for (int i = 0; i < 5; i++) {
		System.out.println("Displaying Data");
		
	}
}
}
